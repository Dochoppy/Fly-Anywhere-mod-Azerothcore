# mod-flying-mounts-everywhere

AzerothCore module for WotLK 3.3.5a that allows **flying mounts to fly in all zones**  
(Eastern Kingdoms, Kalimdor, etc.).

## ✨ Features
- Flying mounts usable everywhere (except blocked maps).
- Honors mount rules: must use a flying mount spell.
- Configurable restrictions:
  - Disable in BGs/arenas
  - Disable in instances
  - Minimum level
- Optional whitelist of allowed mount spells.

---

## 🔧 Installation on Linux

1. Go to your AzerothCore modules folder:

   ```bash
   cd ~/azerothcore-wotlk/modules
   ```

2. Clone the repo (once uploaded to your GitHub):

   ```bash
   git clone https://github.com/YOUR_USERNAME/mod-flying-mounts-everywhere.git
   ```

3. Rebuild AzerothCore:

   ```bash
   cd ~/azerothcore-wotlk
   mkdir build && cd build
   cmake ../ -DCMAKE_INSTALL_PREFIX=$HOME/azeroth-server
   make -j$(nproc)
   make install
   ```

4. Copy the config file:

   ```bash
   cp ../modules/mod-flying-mounts-everywhere/conf/mod_flying_mounts_everywhere.conf.dist       $HOME/azeroth-server/etc/worldserver.conf.d/mod_flying_mounts_everywhere.conf
   ```

5. Edit the config as needed:

   ```bash
   nano $HOME/azeroth-server/etc/worldserver.conf.d/mod_flying_mounts_everywhere.conf
   ```

6. Run your worldserver:

   ```bash
   $HOME/azeroth-server/bin/worldserver
   ```

---

## ⚙️ Configuration

Example:

```ini
[mod_flying_mounts_everywhere]
Enabled = 1
BlockInBattlegrounds = 1
BlockInInstances = 1
MinLevel = 20
Debug = 0
AllowedMountSpells = 32244,40192
```

- Leave `AllowedMountSpells` empty → all flying mounts work.
- Add IDs → only those spells can fly.
- Spell IDs can be found in `Spell.dbc` or Wowhead (3.3.5a).

---

## 📝 Notes
- This does **not** give GM free flight; only mounts with flying aura.
- Indoor/instance maps may misbehave → block them in config.
- By default, BGs and instances block flying for fairness.
